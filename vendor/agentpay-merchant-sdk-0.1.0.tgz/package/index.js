"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// ../../../../../../../../Downloads/hackatonyuno/sdk/index.ts
var index_exports = {};
__export(index_exports, {
  createAgentPayCheckoutHandler: () => createAgentPayCheckoutHandler,
  discoverAgentPayMerchant: () => discoverAgentPayMerchant,
  merchantManifest: () => merchantManifest,
  signAgentPayRequest: () => signAgentPayRequest
});
module.exports = __toCommonJS(index_exports);
var import_zod = require("zod");

// ../../../../../../../../Downloads/hackatonyuno/lib/crypto.ts
var import_node_crypto = require("node:crypto");

// ../../../../../../../../Downloads/hackatonyuno/lib/canonical-json.ts
function sortValue(value) {
  if (Array.isArray(value)) {
    return value.map(sortValue);
  }
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.entries(value).sort(([left], [right]) => left.localeCompare(right)).map(([key, nested]) => [key, sortValue(nested)])
    );
  }
  return value;
}
function canonicalJson(value) {
  return JSON.stringify(sortValue(value));
}

// ../../../../../../../../Downloads/hackatonyuno/lib/crypto.ts
function sha256Base64Url(input) {
  return (0, import_node_crypto.createHash)("sha256").update(input).digest("base64url");
}
function bodyHash(body) {
  return sha256Base64Url(body);
}
function agentSigningMessage(input) {
  return [
    input.method.toUpperCase(),
    input.path,
    bodyHash(input.body),
    input.timestamp,
    input.nonce
  ].join("|");
}
function signText(privateKeyPem, value) {
  return (0, import_node_crypto.sign)(null, Buffer.from(value), (0, import_node_crypto.createPrivateKey)(privateKeyPem)).toString("base64url");
}
function verifyText(publicKeyPem, value, signature) {
  try {
    return (0, import_node_crypto.verify)(
      null,
      Buffer.from(value),
      (0, import_node_crypto.createPublicKey)(publicKeyPem),
      Buffer.from(signature, "base64url")
    );
  } catch {
    return false;
  }
}

// ../../../../../../../../Downloads/hackatonyuno/lib/agentpay-policy.ts
function evaluatePolicy(mandate, cart, now = /* @__PURE__ */ new Date()) {
  if (!mandate) {
    return { decision: "refused", reason_code: "MANDATE_NOT_FOUND" };
  }
  if (mandate.status === "revoked") {
    return { decision: "refused", reason_code: "MANDATE_REVOKED" };
  }
  if (mandate.status !== "active" || now < new Date(mandate.validity.not_before) || now > new Date(mandate.validity.expires_at)) {
    return { decision: "refused", reason_code: "MANDATE_EXPIRED" };
  }
  if (!mandate.scope.merchants.includes(cart.merchant_id)) {
    return { decision: "refused", reason_code: "MERCHANT_NOT_IN_SCOPE" };
  }
  if (!mandate.scope.categories.includes(cart.category)) {
    return { decision: "refused", reason_code: "CATEGORY_NOT_IN_SCOPE" };
  }
  if (cart.currency !== mandate.limits.currency) {
    return { decision: "refused", reason_code: "CURRENCY_MISMATCH" };
  }
  if (mandate.usage.approved_uses >= mandate.limits.max_uses) {
    return { decision: "refused", reason_code: "USES_EXCEEDED" };
  }
  if (mandate.usage.cumulative_cents + cart.amount_cents > mandate.limits.cumulative_cents) {
    return { decision: "refused", reason_code: "CUMULATIVE_EXCEEDED" };
  }
  if (cart.amount_cents > mandate.limits.per_purchase_cents && !cart.exception_id) {
    return { decision: "escalated", reason_code: "AMOUNT_EXCEEDS_LIMIT" };
  }
  return { decision: "approved", reason_code: null };
}

// ../../../../../../../../Downloads/hackatonyuno/sdk/index.ts
var manifestSchema = import_zod.z.object({
  protocol: import_zod.z.literal("agentpay/1.0"),
  merchant: import_zod.z.object({ id: import_zod.z.string().min(1), name: import_zod.z.string().min(1) }),
  checkout_endpoint: import_zod.z.url(),
  registry_url: import_zod.z.url(),
  capabilities: import_zod.z.tuple([
    import_zod.z.literal("intent-mandates"),
    import_zod.z.literal("live-revocation"),
    import_zod.z.literal("mock-payment")
  ])
});
var checkoutBodySchema = import_zod.z.object({
  mandate_id: import_zod.z.uuid(),
  merchant_id: import_zod.z.string().min(1),
  product_id: import_zod.z.string().min(1),
  exception_id: import_zod.z.uuid().optional()
});
function merchantManifest(input) {
  const origin = new URL(input.origin).origin;
  return {
    protocol: "agentpay/1.0",
    merchant: { id: input.merchantId, name: input.merchantName },
    checkout_endpoint: new URL(input.checkoutPath ?? "/api/store/checkout", origin).toString(),
    registry_url: input.registryUrl ? new URL(input.registryUrl).toString() : origin,
    capabilities: ["intent-mandates", "live-revocation", "mock-payment"]
  };
}
async function discoverAgentPayMerchant(merchantUrl, fetcher = fetch) {
  const candidate = new URL(merchantUrl);
  const manifestUrl = candidate.pathname.endsWith("agentpay.json") ? candidate : new URL("/.well-known/agentpay.json", candidate.origin);
  const response = await fetcher(manifestUrl, {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    throw new Error(`Merchant does not publish AgentPay discovery metadata (${response.status})`);
  }
  return manifestSchema.parse(await response.json());
}
function signAgentPayRequest(input) {
  const url = new URL(input.url);
  const timestamp = (input.now ?? /* @__PURE__ */ new Date()).toISOString();
  const nonce = input.nonce ?? crypto.randomUUID();
  const signature = signText(
    input.privateKey,
    agentSigningMessage({
      method: input.method,
      path: url.pathname,
      body: input.body,
      timestamp,
      nonce
    })
  );
  return new Headers({
    "content-type": "application/json",
    "x-agent-id": input.agentId,
    "x-timestamp": timestamp,
    "x-nonce": nonce,
    "x-signature": signature
  });
}
function createAgentPayCheckoutHandler(config) {
  return async function checkout(request) {
    const fetcher = config.fetcher ?? fetch;
    const now = config.now?.() ?? /* @__PURE__ */ new Date();
    const rawBody = await request.text();
    const agentId = request.headers.get("x-agent-id");
    const timestamp = request.headers.get("x-timestamp");
    const nonce = request.headers.get("x-nonce");
    const signature = request.headers.get("x-signature");
    const invalidSignature = () => Response.json(
      {
        decision: "refused",
        reason_code: "AGENT_SIGNATURE_INVALID",
        checks: {
          agent_signature: false,
          mandate_signature: false,
          registry_status: false,
          policy: false
        }
      },
      { status: 401 }
    );
    if (!agentId || !timestamp || !nonce || !signature) {
      return invalidSignature();
    }
    const signedAt = new Date(timestamp);
    if (!Number.isFinite(signedAt.valueOf()) || Math.abs(now.valueOf() - signedAt.valueOf()) > 6e4) {
      return invalidSignature();
    }
    const agentResponse = await fetcher(
      new URL(`/api/registry/agents/${encodeURIComponent(agentId)}`, config.registryUrl),
      { headers: { Accept: "application/json" } }
    );
    if (!agentResponse.ok) {
      return invalidSignature();
    }
    const agent = import_zod.z.object({ id: import_zod.z.string(), public_key: import_zod.z.string() }).parse(await agentResponse.json());
    const validAgentSignature = verifyText(
      agent.public_key,
      agentSigningMessage({
        method: request.method,
        path: new URL(request.url).pathname,
        body: rawBody,
        timestamp,
        nonce
      }),
      signature
    );
    if (!validAgentSignature) {
      return invalidSignature();
    }
    const nonceResponse = await fetcher(new URL("/api/registry/nonces", config.registryUrl), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ agent_id: agentId, nonce, timestamp })
    });
    if (!nonceResponse.ok) {
      return invalidSignature();
    }
    const parsedBody = checkoutBodySchema.safeParse(JSON.parse(rawBody));
    if (!parsedBody.success || parsedBody.data.merchant_id !== config.merchantId) {
      return Response.json({ error: "Invalid checkout payload" }, { status: 400 });
    }
    const product = await config.resolveProduct(parsedBody.data.product_id);
    if (!product || product.merchant_id !== config.merchantId) {
      return Response.json({ error: "Product not found" }, { status: 404 });
    }
    const mandateResponse = await fetcher(
      new URL(`/api/registry/mandates/${parsedBody.data.mandate_id}`, config.registryUrl),
      { headers: { Accept: "application/json" }, cache: "no-store" }
    );
    const mandate = mandateResponse.ok ? import_zod.z.custom().parse(await mandateResponse.json()) : null;
    const registryKeyResponse = await fetcher(new URL("/api/registry/keys", config.registryUrl), {
      headers: { Accept: "application/json" },
      cache: "force-cache"
    });
    const registryKey = registryKeyResponse.ok ? import_zod.z.object({ algorithm: import_zod.z.literal("Ed25519"), public_key: import_zod.z.string() }).parse(await registryKeyResponse.json()) : null;
    const mandateArtifact = mandate ? {
      mandate_id: mandate.mandate_id,
      type: mandate.type,
      issuer: mandate.issuer,
      agent: mandate.agent,
      scope: mandate.scope,
      limits: mandate.limits,
      validity: mandate.validity,
      payment: mandate.payment,
      ...mandate.authorization ? { authorization: mandate.authorization } : {}
    } : null;
    const mandateSignatureValid = Boolean(
      mandateArtifact && mandate?.server_sig && registryKey && mandate.agent.agent_id === agentId && mandate.agent.public_key === agent.public_key && verifyText(registryKey.public_key, canonicalJson(mandateArtifact), mandate.server_sig)
    );
    const cart = {
      mandate_id: parsedBody.data.mandate_id,
      merchant_id: config.merchantId,
      product_id: product.id,
      category: product.category,
      amount_cents: product.price_cents,
      currency: product.currency,
      exception_id: parsedBody.data.exception_id
    };
    const policy = mandateSignatureValid ? evaluatePolicy(mandate, cart, now) : { decision: "refused", reason_code: "MANDATE_SIGNATURE_INVALID" };
    return Response.json({
      ...policy,
      product,
      checks: {
        agent_signature: true,
        mandate_signature: mandateSignatureValid,
        registry_status: mandate?.status === "active",
        policy: policy.decision === "approved"
      }
    });
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  createAgentPayCheckoutHandler,
  discoverAgentPayMerchant,
  merchantManifest,
  signAgentPayRequest
});
