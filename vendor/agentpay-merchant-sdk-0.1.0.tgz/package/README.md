# @agentpay/merchant-sdk

Publish store-owned AgentPay discovery metadata and protect a checkout route with request, registry-signature, live-status, replay, and deterministic policy verification.

See the complete integration guide at https://github.com/pedroschott/hackatonyuno/blob/main/docs/merchant-sdk.md.
