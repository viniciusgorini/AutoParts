type PolicyReason = "AGENT_SIGNATURE_INVALID" | "MANDATE_SIGNATURE_INVALID" | "MANDATE_NOT_FOUND" | "MANDATE_REVOKED" | "MANDATE_EXPIRED" | "MERCHANT_NOT_IN_SCOPE" | "CATEGORY_NOT_IN_SCOPE" | "CURRENCY_MISMATCH" | "USES_EXCEEDED" | "CUMULATIVE_EXCEEDED" | "AMOUNT_EXCEEDS_LIMIT";
type PolicyDecision = {
    decision: "approved";
    reason_code: null;
} | {
    decision: "refused";
    reason_code: PolicyReason;
} | {
    decision: "escalated";
    reason_code: "AMOUNT_EXCEEDS_LIMIT";
};
type AgentPayMerchantManifest = {
    protocol: "agentpay/1.0";
    merchant: {
        id: string;
        name: string;
    };
    checkout_endpoint: string;
    registry_url: string;
    capabilities: ["intent-mandates", "live-revocation", "mock-payment"];
};

type MerchantProduct = {
    id: string;
    merchant_id: string;
    name: string;
    category: string;
    price_cents: number;
    currency: string;
};
type MerchantCheckoutResult = PolicyDecision & {
    product?: MerchantProduct;
    checks: {
        agent_signature: boolean;
        mandate_signature: boolean;
        registry_status: boolean;
        policy: boolean;
    };
};
type FetchLike = typeof fetch;
declare function merchantManifest(input: {
    origin: string;
    merchantId: string;
    merchantName: string;
    checkoutPath?: string;
    registryUrl?: string;
}): AgentPayMerchantManifest;
declare function discoverAgentPayMerchant(merchantUrl: string, fetcher?: FetchLike): Promise<AgentPayMerchantManifest>;
declare function signAgentPayRequest(input: {
    agentId: string;
    privateKey: string;
    method: string;
    url: string;
    body: string;
    now?: Date;
    nonce?: string;
}): Headers;
declare function createAgentPayCheckoutHandler(config: {
    merchantId: string;
    registryUrl: string;
    resolveProduct: (productId: string) => Promise<MerchantProduct | null>;
    fetcher?: FetchLike;
    now?: () => Date;
}): (request: Request) => Promise<Response>;

export { type MerchantCheckoutResult, type MerchantProduct, createAgentPayCheckoutHandler, discoverAgentPayMerchant, merchantManifest, signAgentPayRequest };
